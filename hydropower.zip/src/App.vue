<template>
  <div id="app">
    <div class="weui-tab">
      <div class="weui-tab__panel">
        <router-view/>
      </div>
      <div class="weui-tabbar">
        <router-link to="/" class="weui-tabbar__item " >
          <i class="iconfont icon-home"></i>
          <p class="weui-tabbar__label">关注宿舍</p>
        </router-link>
        <router-link to="/CheckBalances" class="weui-tabbar__item " >
          <i class="iconfont icon-yue"></i>
          <p class="weui-tabbar__label">查询余额</p>
        </router-link>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'App',
  data () {
    return {
      title: '查询余额'
    }
  }
}
</script>

<style>
#app {
  font-family:'Microsoft Yahei','Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
}
.weui-tabbar__item i{
  font-size: 32px;
}
.weui-tabbar__item{
  color: #050505;
}
.weui-tabbar .weui-tabbar__label{
  font-size: 22px;
  color: inherit;
}
.weui-tabbar{
  height: 100px;
  background-color: #fff;
  box-shadow: 0 0 10px #dadada;
}
.router-link-active{
  color: #4ea3ee;
}
.weui-tab__panel{
  padding-bottom: 100px;
}

#weui-picker-confirm{
  color: #4ea3ee !important;
}
.van-radio .van-icon-checked{
  color: #4ea3ee;
}



</style>
