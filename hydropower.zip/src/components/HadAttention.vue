<template>
  <ul class="ul-total">
    <li class="attention-info" >
      <van-icon name="delete" color="#4ea3ee" size="32px" class="move" @click="deleteItem"  />
      <van-icon name="wap-home" color="#c8c8c8" size="32px" style="vertical-align: -4px" />
      北区丹桂苑23栋719
      <p>
        当余额低于 <span class="blueColor">5</span> 元时发出充值提醒
      </p>
    </li>
    <li class="attention-info" >
      <van-icon name="delete" color="#4ea3ee" size="32px" class="move" @click="deleteItem"  />
      <van-icon name="wap-home" color="#c8c8c8" size="32px" style="vertical-align: -4px" />
      北区丹桂苑23栋719
      <p>
        当余额低于 <span class="blueColor">5</span> 元时发出充值提醒
      </p>
    </li>
  </ul>
</template>

<script>
export default {
  name: 'HadAttemtion',
  data () {
    return {
      show: true
    }
  },
  methods: {
    deleteItem () {
      this.show = false
    }
  }
}
</script>

<style scoped>
  .attention-info{
    width: 653px;
    height: 156px;
    padding: 28px;
    border: 2px solid #d2d2d2;
    margin: 0 auto;
    border-radius: 10px;
    box-sizing: border-box;
    text-align: left;
    font-size: 28px;
    position: relative;
    margin-bottom: 54px;
  }
  .blueColor{
    color: #4ea3ee;
  }
  .move{
    position: absolute;
    right: 28px;
    top:54px;

  }
  .ul-total{
    margin-top: -10px;
  }

</style>
