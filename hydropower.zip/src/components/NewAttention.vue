<template>
    <div>
      <div class="weui-cells">
        <div class="weui-cell weui-cell_access js_item" @click="getDistrict()">
          <div class="weui-cell  noPadding">
            <div class="weui-cell__hd">
              <label for="" class="weui-label">苑区</label>
            </div>
            <div class="weui-cell__bd weui-cell__ft">
              <p class="selected">
                {{district}}
              </p>
            </div>

          </div>
        </div>
        <div class="weui-cell" >
          <div class="weui-cell__hd"><label class="weui-label">宿舍号</label></div>
          <div class="weui-cell__bd">
            <input class="weui-input marginRight" type="number"  placeholder="如505"/>
          </div>
        </div>
        <div class="weui-cell addHeight">
          <div class="weui-cell__hd">
            <label for="" class="weui-label widthAuto">余额提醒</label>
          </div>
          <div class="weui-cell__bd marginTop">
            <van-radio-group v-model="radio">
              <div class="weui-flex chooseHow">
                <div class="weui-flex__item">
                  <div class="placeholder">
                    <van-radio name="1">5元</van-radio>
                  </div>
                </div>
                <div class="weui-flex__item">
                  <div class="placeholder">
                    <van-radio name="2">10元</van-radio>
                  </div>
                </div>
                <div class="weui-flex__item">
                  <div class="placeholder">
                    <van-radio name="3">15元</van-radio>
                  </div>
                </div>
              </div>
              <div class="weui-flex chooseHow">
                <div class="weui-flex__item">
                  <div class="placeholder">
                    <van-radio name="4">20元</van-radio>
                  </div>
                </div>
                <div class="weui-flex__item">
                  <div class="placeholder">
                    <van-radio name="5">25元</van-radio>
                  </div>
                </div>
                <div class="weui-flex__item">
                  <div class="placeholder">
                    <van-radio name="6">30元</van-radio>
                  </div>
                </div>
              </div>
            </van-radio-group>
          </div>
        </div>
      </div>
      <div class="button-sp-area">
        <a href="javascript:;" class="weui-btn blue">关注</a>
      </div>
    </div>
</template>

<script>

import 'weui'
import weui from 'weui.js'

export default {
  name: 'NewAttention',
  data () {
    return {
      district: '  ', // 苑区
      radio: '1'
    }
  },
  methods: {
    getDistrict () {
      let self = this
      weui.picker([
        {
          label: '北区',
          value: 1,
          children: [
            {
              label: '紫藤苑',
              value: 1,
              children: [
                {
                  label: '紫藤1栋',
                  value: 1
                }
              ]
            },
            {
              label: '碧桃苑',
              value: 2,
              children: [
                {
                  label: '碧桃20栋',
                  value: 1
                },
                {
                  label: '碧桃21栋',
                  value: 2
                },
                {
                  label: '碧桃24栋',
                  value: 3
                },
                {
                  label: '碧桃25栋',
                  value: 4
                },
                {
                  label: '碧桃27栋',
                  value: 5
                },
                {
                  label: '碧桃28栋',
                  value: 6
                },
                {
                  label: '碧桃29栋',
                  value: 7
                }
              ]
            },
            {
              label: '丹桂苑',
              value: 3,
              children: [
                {
                  label: '丹桂22栋',
                  value: 1
                },
                {
                  label: '丹桂23栋',
                  value: 2
                },
                {
                  label: '丹桂26栋',
                  value: 3
                }
              ]
            }
          ]
        },
        {
          label: '南区',
          value: 2,
          children: [
            {
              label: '丹枫苑',
              value: 1,
              children: [
                {
                  label: '丹枫A栋',
                  value: 1
                },
                {
                  label: '丹枫B栋',
                  value: 2
                }
              ]
            },
            {
              label: '丹竹苑',
              value: 2,
              children: [
                {
                  label: '丹竹A栋',
                  value: 1
                },
                {
                  label: '丹竹B栋',
                  value: 2
                },
                {
                  label: '丹竹C栋',
                  value: 3
                }
              ]
            },
            {
              label: '紫竹苑',
              value: 3,
              children: [
                {
                  label: '紫竹A栋',
                  value: 1
                },
                {
                  label: '紫竹B栋',
                  value: 2
                }
              ]
            },
            {
              label: '碧桂苑',
              value: 4,
              children: [
                {
                  label: '碧桂A栋',
                  value: 1
                },
                {
                  label: '碧桂B栋',
                  value: 2
                },
                {
                  label: '碧桂C栋',
                  value: 3
                }
              ]
            },
            {
              label: '红枫苑',
              value: 5,
              children: [
                {
                  label: '红枫A栋',
                  value: 1
                },
                {
                  label: '红枫B栋',
                  value: 2
                }
              ]
            },
            {
              label: '红棉苑',
              value: 6,
              children: [
                {
                  label: '红棉东栋',
                  value: 1
                },
                {
                  label: '红棉西栋',
                  value: 2
                }
              ]
            },
            {
              label: '紫荆苑',
              value: 7,
              children: [
                {
                  label: '紫荆A栋',
                  value: 1
                },
                {
                  label: '紫荆B栋',
                  value: 2
                },
                {
                  label: '紫荆C栋',
                  value: 3
                }
              ]
            },
            {
              label: '紫薇苑',
              value: 8,
              children: [
                {
                  label: '紫薇A栋',
                  value: 1
                },
                {
                  label: '紫薇B栋',
                  value: 2
                },
                {
                  label: '紫薇C栋',
                  value: 3
                }
              ]
            },
            {
              label: '银杏苑',
              value: 9,
              children: [
                {
                  label: '银杏A栋',
                  value: 1
                },
                {
                  label: '银杏B栋',
                  value: 2
                }
              ]
            }

          ]
        },
        {
          label: '西区',
          value: 3,
          children: [
            {
              label: '丁香苑',
              value: 1,
              children: [
                {
                  label: '丁香A栋',
                  value: 1
                },
                {
                  label: '丁香B栋',
                  value: 2
                },
                {
                  label: '丁香C栋',
                  value: 3
                },
                {
                  label: '丁香D栋',
                  value: 4
                },
                {
                  label: '丁香E栋',
                  value: 5
                },
                {
                  label: '丁香F栋',
                  value: 6
                },
                {
                  label: '丁香G栋',
                  value: 7
                }
              ]
            },
            {
              label: '海棠苑',
              value: 2,
              children: [
                {
                  label: '海棠A栋',
                  value: 1
                },
                {
                  label: '海棠B栋',
                  value: 2
                },
                {
                  label: '海棠C栋',
                  value: 3
                }
              ]
            },
            {
              label: '秋枫苑',
              value: 2,
              children: [
                {
                  label: '秋枫A栋',
                  value: 1
                },
                {
                  label: '秋枫B栋',
                  value: 2
                },
                {
                  label: '秋枫C栋',
                  value: 3
                },
                {
                  label: '秋枫D栋',
                  value: 4
                }

              ]
            },
            {
              label: '蔷薇苑',
              value: 4,
              children: [
                {
                  label: '蔷薇A栋',
                  value: 1
                },
                {
                  label: '蔷薇B栋',
                  value: 2
                },
                {
                  label: '蔷薇C栋',
                  value: 3
                }
              ]
            },
            {
              label: '芙蓉苑',
              value: 5,
              children: [
                {
                  label: '芙蓉A栋',
                  value: 1
                },
                {
                  label: '芙蓉B栋',
                  value: 2
                },
                {
                  label: '芙蓉C栋',
                  value: 3
                },
                {
                  label: '芙蓉D栋',
                  value: 4
                }

              ]
            }

          ]
        },
        {
          label: '黄田坝校区',
          value: 4,
          children: [
            {
              label: '黄田坝宿舍楼',
              value: 1,
              children: [
                {
                  label: '黄田坝6栋',
                  value: 1
                },
                {
                  label: '黄田坝9栋',
                  value: 2
                },
                {
                  label: '黄田坝10栋',
                  value: 3
                },
                {
                  label: '黄田坝12栋',
                  value: 4
                }
              ]
            }

          ]
        }
      ], {
        className: 'ignore',
        container: 'body',
        defaultValue: [1, 1, 1],
        onChange: function (result) {
        },
        onConfirm: function (result) {
          self.district = result[0].label + result[2].label
        },
        id: 'doubleLinePicker'
      })
    }

  }
}
</script>

<style scoped>

  .blue{
    background-color: #4ea3ee;
    color: #fff;
    font-size: 30px;
    width: 649px;
    height: 90px;
    line-height: 90px;
    letter-spacing: 16px;
    border-radius: 10px;
  }
  .weui-cells{
    margin-bottom: 96px;
    box-shadow: 0 0 10px #dadada;

  }
  .weui-cell{
    height: 96px;
    font-size: 30px;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
  }
  .weui-cell:before{
    border-color: #dcdcdc;
  }
  .weui-label{
    text-align: left;
    color: #050505;
  }
  ::-moz-placeholder { color: #bfbfbf; }
  ::-webkit-input-placeholder { color:#bfbfbf; }
  :-ms-input-placeholder { color:#bfbfbf; }
  .marginRight{
    text-indent: 50px;
  }
  .selected{
    text-indent: 50px;
    height: 100%;
    padding-right: 30px;
    text-align: left;
  }
  .weui-cell__ft:after{
    height: 16px;
    width: 16px;
    margin-top: -8px;
    right: 15px;
    content:''
  }
  .noPadding{
    padding: 0;
    width: 100%;

  }
  .widthAuto{
    width: auto;
  }
  .weui-cell__bd{
    text-align: left;
  }
  .chooseHow{
    margin-left: 32px;
    width:414px !important;
  }
  .marginTop{
    margin-top:30px;
  }
  .addHeight{
    height: 140px;
    padding-bottom: 40px;
  }

</style>
